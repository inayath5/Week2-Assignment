
public class Ballon {
	public class BallonStore {
		public void Ballon(String style,String type) {
			Ballon ballon = null;
			if(type.equals("Ballons")) {
				ballon = new Ballon();
				} else if (type.equals("Party")) {
			
				ballon = new Ballon();
				} else if (type.equals("Birthday")) {
					ballon = new Ballon();
				} else if (type.equals("Latex"))   {
					ballon = new Ballon();
				} else if (type.equals("Cellophane")) {
					ballon = new Ballon();
					
				}
			}
		}
	}

