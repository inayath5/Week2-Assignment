
 public class  testballon {
	 public static void main(String[] args) {
		 Ballon nyStore = new Ballon(); 
		 Ballon chicagoStore = new Ballon(); 
		
		 Object orderBallon(String string) {
			// TODO Auto-generated method stub
				return null;
				}
		 
		    ballon = chicagoStore.orderBallon("Birthday");
			System.out.println("Peter ordered a ballon");
			
		 
			ballon = chicagoStore.orderBallon("Birthday");
			System.out.println("John ordered a ballon");
			

		    ballon = nyStore.orderBallon("Latex");
			System.out.println("Paul ordered a ballon");
			

		    ballon = chicagoStore.orderBallon("cellophane");
			System.out.println("Ram ordered a ballon");
	 }
 }
			
			
